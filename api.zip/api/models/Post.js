const mongoose = require('mongoose');
const {Schema} = mongoose

const PostSchema = new Schema({
    title:{
        type:String,
        required:true,
        unique:true
    },
    
    photo:{
        type:String,
        required:false
    },
    bloodUnit:{
        type:String,
        required:false
    },
    patientName:{
        type:String,
        required:false
    },
    purpose:{
        type:String,
        required:false
    },
    patientAge:{
        type:String,
        required:false
    },
    mobileNumber:{
        type:String,
        required:false
    },hospitalName:{
        type:String,
        required:false
    },bloodGroup:{
        type:String,
        required:false
    },
    address:{
        type:String,
        required:false
    },
    username: {
        type:String,
        required:true
    },
    categories:{
        type:Array,
        required:false
    }
  },
    {timestamps:true}
);

module.exports = mongoose.model("Post", PostSchema);