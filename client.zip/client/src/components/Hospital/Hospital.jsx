import React from 'react';
import './hospital.css';

function Hospital() {
    return (
        <div className='hospital'>
            <h1>Private Hospital Phone Number</h1>

            <h4>Ad-Din Hospital</h4>
            <address>Moghbazar, Dhaka, ph- 9353391-3Ahmed Medical Centre Ltd.
                House # 71, Road # 15-A, (New), Dhanmondi C/A, ph- 8113628</address>

                <h4>Al Anaiet Adhunik Hospital</h4>
                <address>House # 13, Eshakha Avenue Sector # 6, Uttara Dhaka, ph- 8916290, 8920165</address>

                <h4>Al Anaiet Adhunik Hospital</h4>
                <address>House # 36, Road # 3, Dhanmondi, ph- 8631619</address>

                <h4>Al- Helal Speacialist Hospital</h4>
                <address>150, Rokeya Sarani Senpara ParbataMirpur-10, Dhaka, ph- 9006820, 9008181</address>

                <h4>Al Jebel-E-Nur Heart Ltd.</h4>
                <address>House # 21, Road # 9/A (New), Dhanmondi, ph- 8117031</address>

                <h4>Al- Rajhi Hospital</h4>
                <address>12, Farmgate. Dhaka -1215, ph- 8119229, 8121172, 9117775</address>

                <h4>Al-Ahsraf General Hospital</h4>
                <address>House # 12 Road # 21,Sector # 4, Uttara Dhaka, ph- 8952851-2</address>

                <h4>Al-Biruni Hospital</h4>
                <address>23/1, Khilzee Road, Shyamoli, ph- 8118905, 9115953</address>

                <h4>Al-Fateh Medical Sevices (Pvt) Ltd.</h4>
                <address>11, Farmgate over Bridge East Side, ph- 9120615</address>

                <h4>Al-Madina General Hospital (Pvt.) Ltd</h4>
                <address>2/A, Golden Street, Ring Road, Shamoli, Dhaka, ph 8118709</address>
                
                <h4>Al-Mohite General Hospital & Diagnostic Centre</h4>
                <address>House # 11, Road # 2, Shamoli, ph- 9113831, 9114220 Ext 238</address>

                <h4>Anjuman-E-Mofidul Islam</h4>
                <address>Dhaka. ph- 9336611Dhaka. ph- 9336611</address>

                <h4>Ad-Din Hospital</h4>
            <address>Moghbazar, Dhaka, ph- 9353391-3Ahmed Medical Centre Ltd.
                House # 71, Road # 15-A, (New), Dhanmondi C/A, ph- 8113628</address>

                <h4>Al Anaiet Adhunik Hospital</h4>
                <address>House # 13, Eshakha Avenue Sector # 6, Uttara Dhaka, ph- 8916290, 8920165</address>

                <h4>Al Anaiet Adhunik Hospital</h4>
                <address>House # 36, Road # 3, Dhanmondi, ph- 8631619</address>

                <h4>Al- Helal Speacialist Hospital</h4>
                <address>150, Rokeya Sarani Senpara ParbataMirpur-10, Dhaka, ph- 9006820, 9008181</address>

                <h4>Al Jebel-E-Nur Heart Ltd.</h4>
                <address>House # 21, Road # 9/A (New), Dhanmondi, ph- 8117031</address>

                <h4>Al- Rajhi Hospital</h4>
                <address>12, Farmgate. Dhaka -1215, ph- 8119229, 8121172, 9117775</address>

                <h4>Al-Ahsraf General Hospital</h4>
                <address>House # 12 Road # 21,Sector # 4, Uttara Dhaka, ph- 8952851-2</address>

                <h4>Al-Biruni Hospital</h4>
                <address>23/1, Khilzee Road, Shyamoli, ph- 8118905, 9115953</address>

                <h4>Al-Fateh Medical Sevices (Pvt) Ltd.</h4>
                <address>11, Farmgate over Bridge East Side, ph- 9120615</address>

                <h4>Al-Madina General Hospital (Pvt.) Ltd</h4>
                <address>2/A, Golden Street, Ring Road, Shamoli, Dhaka, ph 8118709</address>
                
                <h4>Al-Mohite General Hospital & Diagnostic Centre</h4>
                <address>House # 11, Road # 2, Shamoli, ph- 9113831, 9114220 Ext 238</address>

                <h4>Anjuman-E-Mofidul Islam</h4>
                <address>Dhaka. ph- 9336611Dhaka. ph- 9336611</address>
                <h4>Ad-Din Hospital</h4>
            <address>Moghbazar, Dhaka, ph- 9353391-3Ahmed Medical Centre Ltd.
                House # 71, Road # 15-A, (New), Dhanmondi C/A, ph- 8113628</address>

                <h4>Al Anaiet Adhunik Hospital</h4>
                <address>House # 13, Eshakha Avenue Sector # 6, Uttara Dhaka, ph- 8916290, 8920165</address>

                <h4>Al Anaiet Adhunik Hospital</h4>
                <address>House # 36, Road # 3, Dhanmondi, ph- 8631619</address>

                <h4>Al- Helal Speacialist Hospital</h4>
                <address>150, Rokeya Sarani Senpara ParbataMirpur-10, Dhaka, ph- 9006820, 9008181</address>

                <h4>Al Jebel-E-Nur Heart Ltd.</h4>
                <address>House # 21, Road # 9/A (New), Dhanmondi, ph- 8117031</address>

                <h4>Al- Rajhi Hospital</h4>
                <address>12, Farmgate. Dhaka -1215, ph- 8119229, 8121172, 9117775</address>

                <h4>Al-Ahsraf General Hospital</h4>
                <address>House # 12 Road # 21,Sector # 4, Uttara Dhaka, ph- 8952851-2</address>

                <h4>Al-Biruni Hospital</h4>
                <address>23/1, Khilzee Road, Shyamoli, ph- 8118905, 9115953</address>

                <h4>Al-Fateh Medical Sevices (Pvt) Ltd.</h4>
                <address>11, Farmgate over Bridge East Side, ph- 9120615</address>

                <h4>Al-Madina General Hospital (Pvt.) Ltd</h4>
                <address>2/A, Golden Street, Ring Road, Shamoli, Dhaka, ph 8118709</address>
                
                <h4>Al-Mohite General Hospital & Diagnostic Centre</h4>
                <address>House # 11, Road # 2, Shamoli, ph- 9113831, 9114220 Ext 238</address>

                <h4>Anjuman-E-Mofidul Islam</h4>
                <address>Dhaka. ph- 9336611Dhaka. ph- 9336611</address>

            <br /><br /><br /><br /><br /><br />

            
        </div>
    );
}

export default Hospital;