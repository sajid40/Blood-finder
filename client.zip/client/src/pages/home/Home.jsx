
import Header from "../../components/header/Header";

import Sidebar from "../../components/sidebar/Sidebar";
import "./home.css";

function Home() {
 

  return (
    <>
      <Header />
      <div className="home">
      </div>
      <div className="no"></div>
    </>
  );
}

export default Home;
